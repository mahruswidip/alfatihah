<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Tambah Berita</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url() . 'berita/simpan_post' ?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bmd-label-floating">Judul Berita</label>
                                        <input type="text" name="judul" class="form-control" required /><br />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Isi Berita</label>
                                            <textarea name="berita" rows="5" class="form-control" id="berita"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            if ($this->session->flashdata('error') != '') {
                                echo '<div class="alert alert-danger" role="alert">';
                                echo $this->session->flashdata('error');
                                echo '</div>';
                            }
                            ?>
                            <div class="row">
                                <div class="col">
                                    <label class="">Foto Berita</label>
                                    <br>
                                    <input type="file" name="filefoto" required><br>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success pull-right">Tambah</button>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>