<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <div class="row justify-content-between">
                    <div class="col-md-9">
                        <h3 class="card-title ">Data Berita</h3>
                    </div>
                    <div class="col-auto">
                        <a href="<?php echo site_url('berita/add'); ?>" class="btn btn-success"><span class="fa fa-plus"></span></a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>ID Berita</th>
                            <th>Judul Berita</th>
                            <th>Gambar Preview</th>
                            <th>Isi Berita</th>
                        </thead>
                        <tbody>
                            <?php
                            function limit_words($string, $word_limit)
                            {
                                $words = explode(" ", $string);
                                return implode(" ", array_splice($words, 0, $word_limit));
                            }
                            foreach ($berita->result_array() as $i) :
                                $id = $i['berita_id'];
                                $judul = $i['berita_judul'];
                                $image = $i['berita_image'];
                                $isi = $i['berita_isi'];
                            ?>
                                <tr>
                                    <td><?php echo $id; ?></td>
                                    <td><?php echo $judul; ?></td>
                                    <td><img class="img-fluid" style="max-width: 100px; max-height: 100px;" src="<?php echo base_url() . 'assets/images/' . $image; ?>" alt="">
                                    </td>
                                    <td><?php echo limit_words($isi, 30); ?><a href="<?php echo base_url() . 'berita/view/' . $id; ?>"><br> Selengkapnya ></a></td>
                                    <td>
                                        <a href="<?php echo site_url('petani/edit/' . $id); ?>" class="btn btn-info"><span class="fa fa-pencil"></span></a>
                                        <a href="<?php echo site_url('petani/remove/' . $id); ?>" class="btn btn-danger"><span class="fa fa-trash"></span></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="pull-right">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>