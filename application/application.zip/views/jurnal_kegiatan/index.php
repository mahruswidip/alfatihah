<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <div class="row justify-content-between">
                    <div class="col-md-9">
                        <h3 class="card-title ">Data Jurnal Kegiatan</h3>
                    </div>
                    <div class="col-auto">
                        <a href="<?php echo site_url('jurnal_kegiatan/add'); ?>" class="btn btn-success"><span class="fa fa-plus"></span></a>
                        <a href="<?php echo site_url('jurnal_kegiatan/export'); ?>" class="btn btn-info"><span class="fa fa-file-excel-o"></span>&nbsp; Export</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php 
                // echo '<pre>';
                // print_r($jurnal_kegiatan);
                // exit();
                ?>
                <div class="table-responsive">
                    <table class="table" id="tabel_jurnal">
                        <thead class=" text-primary">
                            <!-- <?php
                                    if ($this->session->userdata('user_level') != '3') {
                                        echo '<th>Nama Petani</th>';
                                    } else {
                                        echo '';
                                    } ?> -->
                            <th>NIK</th>
                            <th>Nama Petani</th>
                            <th>Nomor HP </th>
                            <th>Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>Nama Penyuluh</th>
                            <th>Komoditas</th>
                            <th>Jenis Komoditas</th>
                            <th>Jumlah Luasan Tanam</th>
                            <th>Tanggal Tanam</th>
                            <th>Tanggal Perkiraan Panen</th>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                            <?php foreach ($jurnal_kegiatan as $j) { ?>
                                <tr>
                                    <!-- <?php if ($this->session->userdata('user_level') != '3') {
                                                echo '<td>' . $j['user_name'] . '</td>';
                                            } else {
                                                echo '';
                                            } ?> -->
                                    <td><?php echo $j['nik'] ?></td>
                                    <td><?php echo $j['nama_petani'] ?></td>
                                    <td><?php echo $j['nomor_hp'] ?></td>
                                    <td><?php echo $tanggalConverted = date_format(date_create($j['tanggal_lahir']), 'd F Y'); ?></td>
                                    <td><?php echo $j['alamat']; ?></td>
                                    <td><?php echo $j['user_name']; ?></td>
                                    <td><?php echo $j['nama_komoditas']; ?></td>
                                    <td><?php echo $j['jenis_komoditas']; ?></td>
                                    <td><?php echo $j['jumlah_luasan']; ?></td>
                                    <td><?php echo $tanggalConverted = date_format(date_create($j['tanggal_tanam']), 'd F Y'); ?></td>
                                    <td><?php echo $tanggalConverted = date_format(date_create($j['tanggal_perkiraan_panen']), 'd F Y'); ?></td>
                                    <td>
                                        <a href="<?php echo site_url('jurnal_kegiatan/edit/' . $j['id_jurnal']); ?>" class="btn btn-info"><span class="fa fa-pencil"></span></a>
                                        <a href="<?php echo site_url('jurnal_kegiatan/remove/' . $j['id_jurnal']); ?>" class="btn btn-danger"><span class="fa fa-trash"></span></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <div class="pull-right">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>