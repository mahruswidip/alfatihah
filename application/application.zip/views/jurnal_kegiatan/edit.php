<div class="row">
	<div class="col-md-12">
		<div class="box box-info">
			<div class="box-header with-border">
				<h3 class="box-title">Jurnal Kegiatan Edit</h3>
			</div>
			<?php echo form_open('jurnal_kegiatan/edit/' . $jurnal_kegiatan['id_jurnal']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="nama_kegiatan" class="control-label">Nama Kegiatan</label>
						<div class="form-group">
							<input type="text" name="nama_kegiatan" value="<?php echo ($this->input->post('nama_kegiatan') ? $this->input->post('nama_kegiatan') : $jurnal_kegiatan['nama_kegiatan']); ?>" class="form-control" id="nama_kegiatan" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="uraian" class="control-label">Uraian</label>
						<div class="form-group">
							<input type="text" name="uraian" value="<?php echo ($this->input->post('uraian') ? $this->input->post('uraian') : $jurnal_kegiatan['uraian']); ?>" class="form-control" id="uraian" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="tanggal_kegiatan" class="control-label">Tanggal Kegiatan</label>
						<div class="form-group">
							<input type="date" name="tanggal_kegiatan" value="<?php echo ($this->input->post('tanggal_kegiatan') ? $this->input->post('tanggal_kegiatan') : $jurnal_kegiatan['tanggal_kegiatan']); ?>" class="form-control" id="tanggal_kegiatan" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
				<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Tambah Jurnal Kegiatan</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('jurnal_kegiatan/edit/' . $jurnal_kegiatan['id_jurnal']); ?>
						<div class="row">
							<div class="col-md-6">
								<label for="nama_kegiatan" class="control-label">Nama Kegiatan</label>
								<div class="form-group">
									<input type="text" name="nama_kegiatan" value="<?php echo ($this->input->post('nama_kegiatan') ? $this->input->post('nama_kegiatan') : $jurnal_kegiatan['nama_kegiatan']); ?>" class="form-control" id="nama_kegiatan" />
								</div>
							</div>
							<div class="col-md-6">
								<label for="uraian" class="control-label">Uraian</label>
								<div class="form-group">
									<input type="text" name="uraian" value="<?php echo ($this->input->post('uraian') ? $this->input->post('uraian') : $jurnal_kegiatan['uraian']); ?>" class="form-control" id="uraian" />
								</div>
							</div>
							<div class="col-md-6">
								<label for="tanggal_kegiatan" class="control-label">Tanggal Kegiatan</label>
								<div class="form-group">
									<input type="date" name="tanggal_kegiatan" value="<?php echo ($this->input->post('tanggal_kegiatan') ? $this->input->post('tanggal_kegiatan') : $jurnal_kegiatan['tanggal_kegiatan']); ?>" class="form-control" id="tanggal_kegiatan" />
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-success pull-right">Tambah</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>