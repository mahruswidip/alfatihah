<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Tambah Jurnal Kegiatan</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('jurnal_kegiatan/add'); ?>
						<div class="row">
							<div class="col-md-6">
								<label for="nama_komoditas" class="control-label">Nama Komoditas</label>
								<div class="form-group">
									<input type="text" name="nama_komoditas" value="<?php echo $this->input->post('nama_komoditas'); ?>" class="form-control" id="nama_komoditas" />
								</div>
							</div>
							<div class="col-md-6">
								<label for="jenis_komoditas" class="control-label">Jenis Komoditas</label>
								<div class="form-group">
									<select name="jenis_komoditas" class="form-control">
										<option value="">Pilih Jenis Komoditas</option>
										<?php
										$jenis_komoditas_values = array(
											'Utama' => 'Utama',
											'Tambahan' => 'Tambahan',
										);

										foreach ($jenis_komoditas_values as $value => $display_text) {
											$selected = ($value == $this->input->post('jenis_komoditas')) ? ' selected="selected"' : "";

											echo '<option value="' . $value . '" ' . $selected . '>' . $display_text . '</option>';
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<label for="jumlah_luasan" class="control-label">Jumlah Luasan Tanam</label>
								<div class="form-group">
									<input type="text" name="jumlah_luasan" value="<?php echo $this->input->post('jumlah_luasan'); ?>" class="form-control" id="jumlah_luasan" />
								</div>
							</div>
							<div class="col">
								<label for="status" class="control-label">Status</label>
								<div class="form-group">
									<select name="status" class="form-control">
										<option value="">Pribadi / Sewa</option>
										<?php
										$status_values = array(
											'Pribadi' => 'Pribadi',
											'Sewa' => 'Sewa',
										);
										foreach ($status_values as $value => $display_text) {
											$selected = ($value == $this->input->post('status')) ? ' selected="selected"' : "";

											echo '<option value="' . $value . '" ' . $selected . '>' . $display_text . '</option>';
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row mt-4">
							<div class="col-md-6">
								<div class="form-group">
									<label>Tanggal Tanam</label>
									<input type="date" name="tanggal_tanam" value="<?php echo $this->input->post('tanggal_tanam'); ?>" class="form-control" id="tanggal_tanam" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Perkiraan Panen</label>
									<input type="date" name="tanggal_perkiraan_panen" value="<?php echo $this->input->post('tanggal_perkiraan_panen'); ?>" class="form-control" id="tanggal_perkiraan_panen" />
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-success pull-right">Tambah</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>