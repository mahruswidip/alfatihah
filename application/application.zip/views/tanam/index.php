<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <div class="row justify-content-between">
                    <div class="col-md-9">
                        <h3 class="card-title ">Data Tanam</h3>
                    </div>
                    <div class="col-auto">
                        <a href="<?php echo site_url('tanam/add'); ?>" class="btn btn-success"><span class="fa fa-plus"></span></a>
                        <a href="<?php echo site_url('tanam/export'); ?>" class="btn btn-info"><span class="fa fa-file-excel-o"></span>&nbsp; Export</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>Luasan</th>
                            <th>Komoditas</th>
                            <th>Jenis Komoditas</th>
                            <th>Jumlah Luasan Tanam</th>
                            <th>Tanggal Tanam</th>
                            <th>Perkiraan Panen</th>
                            <?php if ($this->session->userdata('user_level') != 3) {
                                echo '<th>Dibuat Oleh</th>';
                            } ?>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                            <?php foreach ($tanam as $t) { ?>
                                <tr>
                                    <td><?php echo $t['nama_luasan']; ?></td>
                                    <td><?php echo $t['nama_komoditas']; ?></td>
                                    <td><?php echo $t['status']; ?></td>
                                    <td><?php echo $t['tanam_berapa']; ?></td>
                                    <td><?php echo $tanggalConverted = date_format(date_create($t['tanggal_tanam']), 'd F Y'); ?></td>
                                    <td><?php echo $tanggalConverted = date_format(date_create($t['perkiraan_panen']), 'd F Y'); ?></td>
                                    <?php if ($this->session->userdata('user_level') != 3) {
                                        echo '<td>' . $t['user_name'] . '</td>';
                                    } ?>
                                    <td>
                                        <a href="<?php echo site_url('tanam/edit/' . $t['id_tanam']); ?>" class="btn btn-info"><span class="fa fa-pencil"></span></a>
                                        <a href="<?php echo site_url('tanam/remove/' . $t['id_tanam']); ?>" class="btn btn-danger"><span class="fa fa-trash"></span></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <div class="pull-right">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>