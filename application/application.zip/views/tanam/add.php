<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Tambah Tanam</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('tanam/add'); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<select name="id_luasan" class="form-control">
										<option value="">Pilih Luasan</option>
										<?php foreach ($luasanes as $luasan) {
											echo "<option value='" . $luasan['id_luasan'] . "'>" . $luasan['nama_luasan'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row mt-3">
							<div class="col-md-6">
								<div class="form-group">
									<label>Komoditas</label>
									<select name="id_komoditas" class="form-control">
										<option value="">Pilih Komoditas</option>
										<?php foreach ($komoditases as $komoditas) {
											echo "<option value='" . $komoditas['id_komoditas'] . "'>" . $komoditas['nama_komoditas'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="bmd-label-floating">Jumlah Tanam</label>
									<input type="text" name="tanam_berapa" value="<?php echo $this->input->post('tanam_berapa'); ?>" class="form-control" id="tanam_berapa" />
								</div>
							</div>
						</div>
						<div class="row mt-4">
							<div class="col-md-6">
								<div class="form-group">
									<label>Tanggal Tanam</label>
									<input type="date" name="tanggal_tanam" value="<?php echo $this->input->post('tanggal_tanam'); ?>" class="form-control" id="tanggal_tanam" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Perkiraan Panen</label>
									<input type="date" name="perkiraan_panen" value="<?php echo $this->input->post('perkiraan_panen'); ?>" class="form-control" id="perkiraan_panen" />
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-success pull-right">Tambah</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>