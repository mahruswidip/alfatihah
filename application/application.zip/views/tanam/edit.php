<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Edit Tanam</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('tanam/edit/' . $tanam['id_tanam']); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="tanggal_tanam" class="bmd-label-floating">Luasan</label>
									<select name="id_luasan" class="form-control">
										<option value="">Pilih Luasan</option>
										<?php foreach ($luasanes as $luasan) {
											echo "<option value='" . $luasan['id_luasan'] . "'>" . $luasan['nama_luasan'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row mt-3">
							<div class="col-md-6">
								<div class="form-group">
									<label>Komoditas</label>
									<select name="id_komoditas" class="form-control">
										<option value="">Pilih Komoditas</option>
										<?php foreach ($komoditases as $komoditas) {
											echo "<option value='" . $komoditas['id_komoditas'] . "'>" . $komoditas['nama_komoditas'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="bmd-label-floating">Jumlah Tanam</label>
									<input type="text" name="tanam_berapa" value="<?php echo ($this->input->post('tanam_berapa') ? $this->input->post('tanam_berapa') : $tanam['tanam_berapa']); ?>" class="form-control" id="tanam_berapa" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-6">
								<div class="form-group">
									<label for="tanggal_tanam" class="bmd-label-floating">Tanggal Tanam</label>
									<div class="form-group">
										<input type="date" name="tanggal_tanam" value="<?php echo ($this->input->post('tanggal_tanam') ? $this->input->post('tanggal_tanam') : $tanam['tanggal_tanam']); ?>" class="form-control" id="tanggal_tanam" />
									</div>
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="tanggal_tanam" class="bmd-label-floating">Perkiraan Panen</label>
									<div class="form-group">
										<input type="date" name="perkiraan_panen" value="<?php echo ($this->input->post('perkiraan_panen') ? $this->input->post('perkiraan_panen') : $tanam['tanggal_tanam']); ?>" class="form-control" id="tanggal_tanam" />
									</div>
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-info pull-right">Simpan</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>