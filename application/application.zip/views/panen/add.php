<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Tambah Panen</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('panen/add'); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<select name="id_luasan" class="form-control" id="id_luasan">
										<option value="">Pilih Luasan</option>
										<?php foreach ($luasanes as $luasan) {
											echo "<option value='" . $luasan['id_luasan'] . "'>" . $luasan['nama_luasan'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
								<select name="id_komoditas" class="form-control" id="id_komoditas">
										<option value="">Pilih Komoditas</option>
										<?php foreach ($komoditases as $komoditas) {
											echo "<option value='" . $komoditas['id_komoditas'] . "'>" . $komoditas['nama_komoditas'] . "</option>";
										} ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row mt-4">
							<div class="col-md-6">
								<div class="form-group">
									<label class="bmd-label-floating">Hasil Panen</label>
									<input type="text" name="hasil_panen" value="<?php echo $this->input->post('hasil_panen'); ?>" class="form-control" id="hasil_panen" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Tanggal Panen</label>
									<input type="date" name="tanggal_panen" value="<?php echo $this->input->post('tanggal_panen'); ?>" class="form-control" id="tanggal_panen" />
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-success pull-right">Tambah</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
						<!-- <?php echo '<pre>';
						print_r($komoditases) ?> -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
