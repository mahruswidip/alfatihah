<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title">Edit Luasan</h4>
					</div>
					<div class="card-body">
						<?php echo form_open('luasan/edit/' . $luasan['id_luasan']); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="bmd-label-floating">Nama Luasan</label>
									<input type="text" name="nama_luasan" value="<?php echo ($this->input->post('nama_luasan') ? $this->input->post('nama_luasan') : $luasan['nama_luasan']); ?>" class="form-control" id="nama_luasan" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="bmd-label-floating">Luas</label>
									<input type="text" name="luas" value="<?php echo ($this->input->post('luas') ? $this->input->post('luas') : $luasan['luas']); ?>" class="form-control" id="luas" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<select name="status" class="form-control">
										<option value="">Pribadi/Sewa</option>
										<?php
										$status_values = array(
											'Pribadi' => 'Pribadi',
											'Sewa' => 'Sewa',
										);
										foreach ($status_values as $value => $display_text) {
											$selected = ($value == $luasan['status']) ? ' selected="selected"' : "";
											echo '<option value="' . $value . '" ' . $selected . '>' . $display_text . '</option>';
										}
										?>
									</select>
								</div>
							</div>							
						</div>
						<button type="submit" class="btn btn-info pull-right">Simpan</button>
						<div class="clearfix"></div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>